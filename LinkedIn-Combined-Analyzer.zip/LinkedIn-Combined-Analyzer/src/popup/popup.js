document.getElementById('openPosts').addEventListener('click', ()=>{
  window.location.href = 'posts_popup.html';
});

document.getElementById('openPeople').addEventListener('click', ()=>{
  window.location.href = 'people_popup.html';
});
